/* eslint-disable */
// 'eslint-disable header-header' does not work, so we disable all linting for this file
/// <reference types="react-scripts" />
